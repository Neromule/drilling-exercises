﻿namespace ThemesEtudiant
{
    partial class InterfaceAffichageQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_name_theme = new System.Windows.Forms.Label();
            this.lbl_question = new System.Windows.Forms.Label();
            this.txt_poss_1 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_reponse_3 = new System.Windows.Forms.Label();
            this.lbl_reponse_2 = new System.Windows.Forms.Label();
            this.opt_3 = new System.Windows.Forms.RadioButton();
            this.opt_2 = new System.Windows.Forms.RadioButton();
            this.opt_1 = new System.Windows.Forms.RadioButton();
            this.lbl_reponse_1 = new System.Windows.Forms.Label();
            this.cmd_correction = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_name_theme
            // 
            this.lbl_name_theme.AutoSize = true;
            this.lbl_name_theme.Location = new System.Drawing.Point(38, 27);
            this.lbl_name_theme.Name = "lbl_name_theme";
            this.lbl_name_theme.Size = new System.Drawing.Size(76, 13);
            this.lbl_name_theme.TabIndex = 0;
            this.lbl_name_theme.Text = "Nom du thème";
            // 
            // lbl_question
            // 
            this.lbl_question.AutoSize = true;
            this.lbl_question.Location = new System.Drawing.Point(38, 76);
            this.lbl_question.Name = "lbl_question";
            this.lbl_question.Size = new System.Drawing.Size(114, 13);
            this.lbl_question.TabIndex = 1;
            this.lbl_question.Text = "*intitulé de la question*";
            // 
            // txt_poss_1
            // 
            this.txt_poss_1.Location = new System.Drawing.Point(299, 109);
            this.txt_poss_1.Name = "txt_poss_1";
            this.txt_poss_1.Size = new System.Drawing.Size(94, 20);
            this.txt_poss_1.TabIndex = 11;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lbl_reponse_3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_reponse_2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.opt_3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.opt_2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.opt_1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_reponse_1, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(32, 109);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.30769F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.69231F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.tableLayoutPanel1.TabIndex = 12;
            // 
            // lbl_reponse_3
            // 
            this.lbl_reponse_3.AutoSize = true;
            this.lbl_reponse_3.Location = new System.Drawing.Point(103, 65);
            this.lbl_reponse_3.Name = "lbl_reponse_3";
            this.lbl_reponse_3.Size = new System.Drawing.Size(36, 13);
            this.lbl_reponse_3.TabIndex = 6;
            this.lbl_reponse_3.Text = "*rep3*";
            // 
            // lbl_reponse_2
            // 
            this.lbl_reponse_2.AutoSize = true;
            this.lbl_reponse_2.Location = new System.Drawing.Point(103, 34);
            this.lbl_reponse_2.Name = "lbl_reponse_2";
            this.lbl_reponse_2.Size = new System.Drawing.Size(36, 13);
            this.lbl_reponse_2.TabIndex = 5;
            this.lbl_reponse_2.Text = "*rep2*";
            // 
            // opt_3
            // 
            this.opt_3.AutoSize = true;
            this.opt_3.Location = new System.Drawing.Point(3, 68);
            this.opt_3.Name = "opt_3";
            this.opt_3.Size = new System.Drawing.Size(14, 13);
            this.opt_3.TabIndex = 3;
            this.opt_3.TabStop = true;
            this.opt_3.UseVisualStyleBackColor = true;
            // 
            // opt_2
            // 
            this.opt_2.AutoSize = true;
            this.opt_2.Location = new System.Drawing.Point(3, 37);
            this.opt_2.Name = "opt_2";
            this.opt_2.Size = new System.Drawing.Size(14, 13);
            this.opt_2.TabIndex = 2;
            this.opt_2.TabStop = true;
            this.opt_2.UseVisualStyleBackColor = true;
            // 
            // opt_1
            // 
            this.opt_1.AutoSize = true;
            this.opt_1.Location = new System.Drawing.Point(3, 3);
            this.opt_1.Name = "opt_1";
            this.opt_1.Size = new System.Drawing.Size(14, 13);
            this.opt_1.TabIndex = 1;
            this.opt_1.TabStop = true;
            this.opt_1.UseVisualStyleBackColor = true;
            // 
            // lbl_reponse_1
            // 
            this.lbl_reponse_1.AutoSize = true;
            this.lbl_reponse_1.Location = new System.Drawing.Point(103, 0);
            this.lbl_reponse_1.Name = "lbl_reponse_1";
            this.lbl_reponse_1.Size = new System.Drawing.Size(39, 13);
            this.lbl_reponse_1.TabIndex = 4;
            this.lbl_reponse_1.Text = "*rep 1*";
            // 
            // cmd_correction
            // 
            this.cmd_correction.Location = new System.Drawing.Point(318, 216);
            this.cmd_correction.Name = "cmd_correction";
            this.cmd_correction.Size = new System.Drawing.Size(96, 23);
            this.cmd_correction.TabIndex = 14;
            this.cmd_correction.Text = "Correction →";
            this.cmd_correction.UseVisualStyleBackColor = true;
            this.cmd_correction.Click += new System.EventHandler(this.button2_Click);
            // 
            // InterfaceAffichageQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 262);
            this.Controls.Add(this.cmd_correction);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.txt_poss_1);
            this.Controls.Add(this.lbl_question);
            this.Controls.Add(this.lbl_name_theme);
            this.Name = "InterfaceAffichageQuestion";
            this.Text = "Question - Student";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_name_theme;
        private System.Windows.Forms.Label lbl_question;
        private System.Windows.Forms.TextBox txt_poss_1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lbl_reponse_3;
        private System.Windows.Forms.Label lbl_reponse_2;
        private System.Windows.Forms.RadioButton opt_3;
        private System.Windows.Forms.RadioButton opt_2;
        private System.Windows.Forms.RadioButton opt_1;
        private System.Windows.Forms.Label lbl_reponse_1;
        private System.Windows.Forms.Button cmd_correction;
    }
}