﻿namespace ThemesProfesseur
{
    partial class InterfaceThemesProfesseur
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.cmd_theme1 = new System.Windows.Forms.Button();
            this.cmd_theme4 = new System.Windows.Forms.Button();
            this.cmd_theme3 = new System.Windows.Forms.Button();
            this.cmd_theme2 = new System.Windows.Forms.Button();
            this.chk_2 = new System.Windows.Forms.CheckBox();
            this.chk_3 = new System.Windows.Forms.CheckBox();
            this.chk_4 = new System.Windows.Forms.CheckBox();
            this.chk_1 = new System.Windows.Forms.CheckBox();
            this.cmd_delete_theme = new System.Windows.Forms.Button();
            this.cmd_delete_items = new System.Windows.Forms.Button();
            this.cmd_add_theme = new System.Windows.Forms.Button();
            this.cmd_return = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel1.Controls.Add(this.cmd_theme1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmd_theme4, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.cmd_theme3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.cmd_theme2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.chk_2, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.chk_3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.chk_4, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.chk_1, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(22, 47);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 17F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(240, 128);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // cmd_theme1
            // 
            this.cmd_theme1.Location = new System.Drawing.Point(3, 3);
            this.cmd_theme1.Name = "cmd_theme1";
            this.cmd_theme1.Size = new System.Drawing.Size(61, 23);
            this.cmd_theme1.TabIndex = 0;
            this.cmd_theme1.Text = "Theme1";
            this.cmd_theme1.UseVisualStyleBackColor = true;
            // 
            // cmd_theme4
            // 
            this.cmd_theme4.Location = new System.Drawing.Point(137, 69);
            this.cmd_theme4.Name = "cmd_theme4";
            this.cmd_theme4.Size = new System.Drawing.Size(59, 23);
            this.cmd_theme4.TabIndex = 3;
            this.cmd_theme4.Text = "Theme 4";
            this.cmd_theme4.UseVisualStyleBackColor = true;
            // 
            // cmd_theme3
            // 
            this.cmd_theme3.Location = new System.Drawing.Point(3, 69);
            this.cmd_theme3.Name = "cmd_theme3";
            this.cmd_theme3.Size = new System.Drawing.Size(61, 23);
            this.cmd_theme3.TabIndex = 2;
            this.cmd_theme3.Text = "Theme 3";
            this.cmd_theme3.UseVisualStyleBackColor = true;
            // 
            // cmd_theme2
            // 
            this.cmd_theme2.Location = new System.Drawing.Point(137, 3);
            this.cmd_theme2.Name = "cmd_theme2";
            this.cmd_theme2.Size = new System.Drawing.Size(59, 23);
            this.cmd_theme2.TabIndex = 1;
            this.cmd_theme2.Text = "theme2";
            this.cmd_theme2.UseVisualStyleBackColor = true;
            // 
            // chk_2
            // 
            this.chk_2.AutoSize = true;
            this.chk_2.Location = new System.Drawing.Point(202, 3);
            this.chk_2.Name = "chk_2";
            this.chk_2.Size = new System.Drawing.Size(15, 14);
            this.chk_2.TabIndex = 5;
            this.chk_2.UseVisualStyleBackColor = true;
            // 
            // chk_3
            // 
            this.chk_3.AutoSize = true;
            this.chk_3.Location = new System.Drawing.Point(70, 69);
            this.chk_3.Name = "chk_3";
            this.chk_3.Size = new System.Drawing.Size(15, 14);
            this.chk_3.TabIndex = 6;
            this.chk_3.UseVisualStyleBackColor = true;
            // 
            // chk_4
            // 
            this.chk_4.AutoSize = true;
            this.chk_4.Location = new System.Drawing.Point(202, 69);
            this.chk_4.Name = "chk_4";
            this.chk_4.Size = new System.Drawing.Size(15, 14);
            this.chk_4.TabIndex = 7;
            this.chk_4.UseVisualStyleBackColor = true;
            // 
            // chk_1
            // 
            this.chk_1.AutoSize = true;
            this.chk_1.Location = new System.Drawing.Point(70, 3);
            this.chk_1.Name = "chk_1";
            this.chk_1.Size = new System.Drawing.Size(15, 14);
            this.chk_1.TabIndex = 4;
            this.chk_1.UseVisualStyleBackColor = true;
            // 
            // cmd_delete_theme
            // 
            this.cmd_delete_theme.Location = new System.Drawing.Point(22, 193);
            this.cmd_delete_theme.Name = "cmd_delete_theme";
            this.cmd_delete_theme.Size = new System.Drawing.Size(91, 23);
            this.cmd_delete_theme.TabIndex = 10;
            this.cmd_delete_theme.Text = "Delete a theme";
            this.cmd_delete_theme.UseVisualStyleBackColor = true;
            // 
            // cmd_delete_items
            // 
            this.cmd_delete_items.Location = new System.Drawing.Point(22, 222);
            this.cmd_delete_items.Name = "cmd_delete_items";
            this.cmd_delete_items.Size = new System.Drawing.Size(129, 23);
            this.cmd_delete_items.TabIndex = 11;
            this.cmd_delete_items.Text = "Delete Selected Item(s)";
            this.cmd_delete_items.UseVisualStyleBackColor = true;
            // 
            // cmd_add_theme
            // 
            this.cmd_add_theme.Location = new System.Drawing.Point(187, 193);
            this.cmd_add_theme.Name = "cmd_add_theme";
            this.cmd_add_theme.Size = new System.Drawing.Size(75, 23);
            this.cmd_add_theme.TabIndex = 12;
            this.cmd_add_theme.Text = "Add a theme";
            this.cmd_add_theme.UseVisualStyleBackColor = true;
            // 
            // cmd_return
            // 
            this.cmd_return.Location = new System.Drawing.Point(22, 252);
            this.cmd_return.Name = "cmd_return";
            this.cmd_return.Size = new System.Drawing.Size(33, 33);
            this.cmd_return.TabIndex = 13;
            this.cmd_return.Text = "←";
            this.cmd_return.UseVisualStyleBackColor = true;
            // 
            // InterfaceThemesProfesseur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 297);
            this.Controls.Add(this.cmd_return);
            this.Controls.Add(this.cmd_add_theme);
            this.Controls.Add(this.cmd_delete_items);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.cmd_delete_theme);
            this.Name = "InterfaceThemesProfesseur";
            this.Text = "Themes - Teacher";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button cmd_theme1;
        private System.Windows.Forms.Button cmd_theme4;
        private System.Windows.Forms.Button cmd_theme3;
        private System.Windows.Forms.Button cmd_theme2;
        private System.Windows.Forms.CheckBox chk_1;
        private System.Windows.Forms.CheckBox chk_2;
        private System.Windows.Forms.CheckBox chk_3;
        private System.Windows.Forms.CheckBox chk_4;
        private System.Windows.Forms.Button cmd_delete_theme;
        private System.Windows.Forms.Button cmd_delete_items;
        private System.Windows.Forms.Button cmd_add_theme;
        private System.Windows.Forms.Button cmd_return;
    }
}

